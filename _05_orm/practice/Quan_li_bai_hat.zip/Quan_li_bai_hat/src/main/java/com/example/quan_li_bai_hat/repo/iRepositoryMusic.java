package com.example.quan_li_bai_hat.repo;

import com.example.quan_li_bai_hat.model.Music;
import com.example.quan_li_bai_hat.model.Music;
import org.springframework.data.repository.CrudRepository;

public interface iRepositoryMusic extends CrudRepository<Music, Integer> {

}
